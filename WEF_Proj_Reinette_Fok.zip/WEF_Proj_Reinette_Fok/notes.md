## use console.log in js to check if js setting is correct
## P5
must write the "function setup()", p5 will automatically call this function once only
use teh "function draw()" to allow the printing on canvas

## draw function 
to display the new canvas, please write anything related to canvas display update, write in draw.
will occur finitely whenever the canvas needs update

## global variables should be put on top of the js document
for the sake of convenience (like a glossary)

## can use console.table if want to check a lot of patterned arrays

## if want background color change according to each frame, set the background color in draw function

## the grid might has remainder after the calculation, can use the background color or transparent to cover




## noloop()



-pause button ->noloop()
-next button -> when mouse pressed: loop(); 
-restart button ->loop()
-speed adjustment -> inside setup -> frameRate(fr) -> let fr = speed button to get framerate (from 0-30frame/second)
 when pressed mouse, no action, when released mouse, the rate will be automatically updated.

-
